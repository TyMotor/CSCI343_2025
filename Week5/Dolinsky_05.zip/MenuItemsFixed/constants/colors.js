const Colors = {
    accent500: "#0a7a58",
    primary500: "#ffdf00",
}

export default Colors;